/*
  Warnings:

  - A unique constraint covering the columns `[name]` on the table `logcategories` will be added. If there are existing duplicate values, this will fail.

*/
-- AlterTable
ALTER TABLE `logcategories` ADD COLUMN `isDeleted` BOOLEAN NOT NULL DEFAULT false;

-- CreateIndex
CREATE UNIQUE INDEX `logcategories_name_key` ON `logcategories`(`name`);
