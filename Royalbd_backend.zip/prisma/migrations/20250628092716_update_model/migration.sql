-- AlterTable
ALTER TABLE `journals` MODIFY `date` DATE NOT NULL;
