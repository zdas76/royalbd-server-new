-- AlterTable
ALTER TABLE `bank_transactions` MODIFY `debitAmount` INTEGER NULL,
    MODIFY `creditAmount` INTEGER NULL;
