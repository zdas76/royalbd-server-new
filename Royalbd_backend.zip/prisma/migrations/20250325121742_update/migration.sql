-- AlterTable
ALTER TABLE `employees` MODIFY `dob` DATE NOT NULL;
