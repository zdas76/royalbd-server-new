export const PartySearchAbleFields: string[] = ["name, constact"];

export const partyfiltersFields: string[] = ["partyType", "searchTerm"];
