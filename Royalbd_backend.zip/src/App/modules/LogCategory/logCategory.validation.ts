import z from "zod";

const LogCategorySchema = z.object({
  name: z.string(),
});

export const LogcategorySchema = {
  LogCategorySchema,
};
