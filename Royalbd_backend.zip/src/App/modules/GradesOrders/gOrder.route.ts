import express from "express";

const route = express.Router();
route.post("/");

route.get("/");

export const GradesOrderRouter = route;
