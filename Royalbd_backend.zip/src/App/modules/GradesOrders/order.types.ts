export type TlogOrderItems = {
  logId: number | undefined;
  radis: number;
  height: number;
  logGradeId: number;
  quantity: number;
  u_price: number;
  amount: number;
};
