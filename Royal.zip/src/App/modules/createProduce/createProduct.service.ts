const createProductInfo = async (payLoad: any) => {
  console.log(payLoad);
};

export const CreateProductServices = {
  createProductInfo,
};
